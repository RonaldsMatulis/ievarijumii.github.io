


// function darktheme()
// {
//     var element = document.body;
//     element.classList.toggle("dark-mode");
// }



    function create()
    {
        const lastrow = (document.querySelectorAll(".w3-row-padding:last-child"));
        console.log("last row", lastrow);
        console.log("last row length", lastrow.length);
        const rowcount = (document.querySelectorAll(".w3-row-padding:last-child .w3-quarter"));
        console.log("row count", rowcount);
        console.log("row count length", rowcount.length);

        count = (rowcount.length);
        console.log("is row count less than 4?", Boolean(count<4));
        
        //cloning empty template
        const template = document.getElementById("template");
        const clonetemplate = template.cloneNode(true);
        temp = clonetemplate;
        // template.remove();
        
        //cloning add card
        const node = document.getElementById("addcard");
        const clone = node.cloneNode(true);
        add = clone;
        node.remove();

        if(count<=5)
            {
                document.querySelector("#clonerow :nth-child(1)").appendChild(temp);
                const ecard = document.getElementById("template");
                ecard.removeAttribute("style");

        //creating elements
                prev = document.createElement("img");
                // prev.setAttribute("src", "default.png");
                // prev.setAttribute("display", "block");
                

            const img = document.createElement("input");
                img.setAttribute("type", "file");
                img.setAttribute("accept", "image/*");
                img.setAttribute("onchange", "save(event)");
                img.setAttribute("class", "template");
                img.setAttribute("style", "padding-top:1rem");

            const head = document.createElement("input");

            const parag = document.createElement("textarea");

            const heading = document.createElement("h5");
                heading.innerText = "Name of jam";

            const parat = document.createElement("h5");
                parat.innerText = "recipie of jam";
            
            const trigger = document.createElement("button");
                trigger.setAttribute("onclick", "create2()");
                trigger.setAttribute("class", "template");
                trigger.innerText = "create";
            
    // spawning elements
                // img preview
                document.querySelector("#template .w3-quarter").appendChild(prev);
                // img input
                document.querySelector("#template .w3-quarter").appendChild(img);
                // heading prompt
                document.querySelector("#template .w3-quarter").appendChild(heading);
                //heading input
                document.querySelector("#template .w3-quarter").appendChild(head);
                //text prompt
                document.querySelector("#template .w3-quarter").appendChild(parat);
                //text input
                document.querySelector("#template .w3-quarter").appendChild(parag);
                //button 
                document.querySelector("#template .w3-quarter").appendChild(trigger);
                
                // const test = document.querySelector("#template .w3-quarter :nth-child(1)");
                // console.log("this is the first child of w3 quarter",test, "----------------");
                

                // document.getElementById("clonerow").appendChild(add);

        

            }                
    }

    function create2()
    {
        if(count>=5)
            {   
            const node = document.getElementById("clonerow");
            const clone = node.cloneNode(false);

            document.getElementById("contentbox").appendChild(clone);
            document.querySelector("#clonerow :nth-child(1)").appendChild(add);
            }
        
            const userimg = document.querySelector('#template .w3-quarter input:nth-of-type(1)').value;
            const userhead = document.querySelector('#template .w3-quarter input:nth-of-type(2)').value;
            const usertext = document.querySelector('#template .w3-quarter textarea').value;

        // despawning old elements
            const Node = document.querySelector("#template .w3-quarter");
            while (Node.lastElementChild) {
            Node.removeChild(Node.lastElementChild);}    
        
        // spawning new card
            const image = document.createElement("img");
            image.setAttribute("src", src);

            const heading = document.createElement("h3");
            heading.innerText = userhead;

            const text = document.createElement("p");
            text.innerText = usertext;

            document.querySelector("#template .w3-quarter").appendChild(image);
            document.querySelector("#template .w3-quarter").appendChild(heading);
            document.querySelector("#template .w3-quarter").appendChild(text);
            document.querySelector("#template .w3-quarter").removeAttribute("id");
            
    
        //spawning new add card
            const po = document.querySelector("#clonerow :nth-child(1)");
            const pop = document.getElementById("clonerow").childElementCount;
            console.log(po);
            console.log(pop);
            // po.appendChild(add);
        
    }

function save(event)
{
    if(event.target.files.length > 0)
    {
        src = URL.createObjectURL(event.target.files[0]);
        prev.setAttribute("src", src);
        prev.style.width ="100%";
        prev.style.marginBottom = "-90%";
        const def = document.querySelector("#template .w3-quarter input[type=file]");
        def.style.opacity = "0";
    }
}